const changer = document.querySelectorAll(".changer");

changer.forEach((element) => {
  let swiper = 0;
  element.addEventListener("click", function () {
    const cursor = element.querySelector(".cursor");
    const outer = element.parentNode;
    const contents = outer.querySelector(".inner .contents");
    if (swiper == 0) {
      cursor.style.transform = "rotate(180deg)";
      element.style.left = "0";
      contents.style.left = "-100%";
      swiper = 1;
      console.log(swiper);
    } else {
      cursor.style.transform = "rotate(0deg)";
      element.style.left = "100%";
      contents.style.left = "0%";
      swiper = 0;
      console.log(swiper);
    }
  });
});

const personsToggle = document.querySelectorAll(".change-theme button")[0];
const eventsToggle = document.querySelectorAll(".change-theme button")[1];

const persons = document.querySelector("#persons");
const events = document.querySelector("#events");

personsToggle.addEventListener("click", function () {
  personsToggle.style.background = "var(--black)";
  personsToggle.style.color = "var(--white)";
  eventsToggle.style.background = "var(--white)";
  eventsToggle.style.color = "var(--black)";

  persons.style.display = "flex";
  events.style.display = "none";

  events.style.opacity = "0";
  setTimeout(function () {
    events.style.opacity = "0";
    persons.style.opacity = "1";
  }, 1);
});
eventsToggle.addEventListener("click", function (e) {
  personsToggle.style.background = "var(--white)";
  personsToggle.style.color = "var(--black)";
  eventsToggle.style.background = "var(--black)";
  eventsToggle.style.color = "var(--white)";

  persons.style.display = "none";
  events.style.display = "flex";

  persons.style.opacity = "0";
  setTimeout(function () {
    events.style.opacity = "1";
    persons.style.opacity = "0";
  }, 1);
});
